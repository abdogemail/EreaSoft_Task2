const { load } = require('../db');

const findUser = (req, db) => db.users.find((u) => u.id === req.session.userId);

function login(req, res, next) {
  req.db = load();
  req.user = findUser(req, req.db);
  if (!req.user) return res.status(401).json({ message: 'Please login first' });
  next();
}

const only = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) return res.status(403).json({ message: 'Not allowed' });
  next();
};

function adminOnly(req, res, next) {
  req.db = load();
  req.user = findUser(req, req.db);
  if (!req.user || !['admin', 'superadmin'].includes(req.user.role)) return res.redirect('/admin/login');
  next();
}

function superOnly(req, res, next) {
  if (req.user.role !== 'superadmin') return res.status(403).send('Not allowed');
  next();
}

module.exports = { login, only, adminOnly, superOnly };
