const router = require('express').Router();
const { load, save, newId } = require('../db');
const { login, only } = require('../middleware/auth');

router.get('/', (req, res) => {
  res.json(load().products);
});

router.get('/mine', login, only('seller'), (req, res) => {
  res.json(req.db.products.filter((p) => p.sellerId === req.user.id));
});

router.post('/', login, only('seller'), (req, res) => {
  const { name, price, description } = req.body;
  if (!name || price === undefined) return res.status(400).json({ message: 'name and price are required' });
  const product = { id: newId(), name, price: Number(price), description: description || '', sellerId: req.user.id };
  req.db.products.push(product);
  save(req.db);
  res.status(201).json(product);
});

router.put('/:id', login, only('seller'), (req, res) => {
  const product = req.db.products.find((p) => p.id === Number(req.params.id) && p.sellerId === req.user.id);
  if (!product) return res.status(404).json({ message: 'Product not found' });
  const { name, price, description } = req.body;
  if (name) product.name = name;
  if (price !== undefined) product.price = Number(price);
  if (description !== undefined) product.description = description;
  save(req.db);
  res.json(product);
});

router.delete('/:id', login, only('seller'), (req, res) => {
  const before = req.db.products.length;
  req.db.products = req.db.products.filter((p) => !(p.id === Number(req.params.id) && p.sellerId === req.user.id));
  if (req.db.products.length === before) return res.status(404).json({ message: 'Product not found' });
  save(req.db);
  res.json({ message: 'Product deleted' });
});

module.exports = router;
