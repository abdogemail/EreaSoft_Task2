const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { load, save, newId } = require('../db');

const hidePassword = ({ password, cart, ...rest }) => rest;

router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: 'name, email and password are required' });
  const db = load();
  if (db.users.find((u) => u.email === email)) return res.status(400).json({ message: 'Email already used' });
  const user = {
    id: newId(),
    name,
    email,
    password: bcrypt.hashSync(password, 10),
    role: role === 'seller' ? 'seller' : 'user',
    cart: []
  };
  db.users.push(user);
  save(db);
  res.status(201).json(hidePassword(user));
});

router.post('/login', (req, res) => {
  const db = load();
  const user = db.users.find((u) => u.email === req.body.email);
  if (!user || !bcrypt.compareSync(String(req.body.password || ''), user.password)) {
    return res.status(400).json({ message: 'Wrong email or password' });
  }
  req.session.userId = user.id;
  res.json(hidePassword(user));
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ message: 'Logged out' }));
});

module.exports = router;
