const router = require('express').Router();
const { save } = require('../db');
const { login, only } = require('../middleware/auth');

router.use(login, only('user'));

router.get('/', (req, res) => {
  const items = req.user.cart
    .map((i) => ({ product: req.db.products.find((p) => p.id === i.productId), quantity: i.quantity }))
    .filter((i) => i.product);
  res.json(items);
});

router.post('/', (req, res) => {
  const productId = Number(req.body.productId);
  const quantity = Number(req.body.quantity || 1);
  if (!req.db.products.find((p) => p.id === productId)) return res.status(404).json({ message: 'Product not found' });
  if (!(quantity >= 1)) return res.status(400).json({ message: 'Invalid quantity' });
  const item = req.user.cart.find((i) => i.productId === productId);
  if (item) item.quantity += quantity;
  else req.user.cart.push({ productId, quantity });
  save(req.db);
  res.json(req.user.cart);
});

router.delete('/:productId', (req, res) => {
  req.user.cart = req.user.cart.filter((i) => i.productId !== Number(req.params.productId));
  save(req.db);
  res.json(req.user.cart);
});

module.exports = router;
