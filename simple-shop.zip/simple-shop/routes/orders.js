const router = require('express').Router();
const { save, newId } = require('../db');
const { login, only } = require('../middleware/auth');

router.use(login, only('user'));

router.get('/', (req, res) => {
  res.json(req.db.orders.filter((o) => o.userId === req.user.id));
});

router.post('/', (req, res) => {
  const items = req.user.cart
    .map((i) => ({ product: req.db.products.find((p) => p.id === i.productId), quantity: i.quantity }))
    .filter((i) => i.product)
    .map((i) => ({ productId: i.product.id, name: i.product.name, price: i.product.price, quantity: i.quantity }));
  if (!items.length) return res.status(400).json({ message: 'Cart is empty' });
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const order = { id: newId(), userId: req.user.id, items, total };
  req.db.orders.push(order);
  req.user.cart = [];
  save(req.db);
  res.status(201).json(order);
});

module.exports = router;
