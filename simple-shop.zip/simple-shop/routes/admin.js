const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { load, save, newId } = require('../db');
const { adminOnly, superOnly } = require('../middleware/auth');

router.get('/login', (req, res) => {
  res.render('login', { error: null });
});

router.post('/login', (req, res) => {
  const db = load();
  const user = db.users.find((u) => u.email === req.body.email && ['admin', 'superadmin'].includes(u.role));
  if (!user || !bcrypt.compareSync(String(req.body.password || ''), user.password)) {
    return res.render('login', { error: 'Wrong email or password' });
  }
  req.session.userId = user.id;
  res.redirect('/admin');
});

router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

router.use(adminOnly);

router.get('/', (req, res) => {
  const { users, products } = req.db;
  res.render('dashboard', {
    me: req.user,
    admins: users.filter((u) => u.role === 'admin'),
    users: users.filter((u) => u.role === 'user'),
    sellers: users.filter((u) => u.role === 'seller'),
    products,
    error: req.query.error || null
  });
});

router.post('/admins', superOnly, (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.redirect('/admin?error=All fields are required');
  if (req.db.users.find((u) => u.email === email)) return res.redirect('/admin?error=Email already used');
  req.db.users.push({ id: newId(), name, email, password: bcrypt.hashSync(password, 10), role: 'admin', cart: [] });
  save(req.db);
  res.redirect('/admin');
});

router.post('/admins/:id/edit', superOnly, (req, res) => {
  const admin = req.db.users.find((u) => u.id === Number(req.params.id) && u.role === 'admin');
  if (admin) {
    if (req.body.name) admin.name = req.body.name;
    if (req.body.email) admin.email = req.body.email;
    if (req.body.password) admin.password = bcrypt.hashSync(req.body.password, 10);
    save(req.db);
  }
  res.redirect('/admin');
});

router.post('/accounts/:id/delete', (req, res) => {
  const target = req.db.users.find((u) => u.id === Number(req.params.id));
  const allowed = target && (['user', 'seller'].includes(target.role) || (target.role === 'admin' && req.user.role === 'superadmin'));
  if (allowed) {
    req.db.users = req.db.users.filter((u) => u !== target);
    req.db.products = req.db.products.filter((p) => p.sellerId !== target.id);
    save(req.db);
  }
  res.redirect('/admin');
});

router.post('/products/:id/delete', (req, res) => {
  req.db.products = req.db.products.filter((p) => p.id !== Number(req.params.id));
  save(req.db);
  res.redirect('/admin');
});

module.exports = router;
