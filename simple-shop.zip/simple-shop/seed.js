const bcrypt = require('bcryptjs');
const { load, save, newId } = require('./db');

const db = load();

if (db.users.find((u) => u.role === 'superadmin')) {
  console.log('Super admin already exists');
} else {
  db.users.push({
    id: newId(),
    name: 'Super Admin',
    email: 'admin@example.com',
    password: bcrypt.hashSync('123456', 10),
    role: 'superadmin',
    cart: []
  });
  save(db);
  console.log('Super admin created: admin@example.com / 123456');
}
