const fs = require('fs');
const file = 'data.json';

function load() {
  if (!fs.existsSync(file)) return { users: [], products: [], orders: [] };
  return JSON.parse(fs.readFileSync(file));
}

function save(db) {
  fs.writeFileSync(file, JSON.stringify(db, null, 2));
}

const newId = () => Date.now() + Math.floor(Math.random() * 1000);

module.exports = { load, save, newId };
